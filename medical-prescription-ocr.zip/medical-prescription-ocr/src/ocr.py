import argparse
import json
import os
import pytesseract
import easyocr

def ocr_pytesseract(image_path):
    # TODO: pass config for better OCR on French (e.g., lang='fra+eng')
    text = pytesseract.image_to_string(image_path, lang='fra+eng')
    return {'text': text}

def ocr_easyocr(image_path):
    reader = easyocr.Reader(['fr','en'], gpu=False)
    result = reader.readtext(image_path, detail=0)
    return {'text': '\n'.join(result)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, help='Folder with preprocessed images')
    ap.add_argument('--engine', choices=['pytesseract','easyocr'], default='pytesseract')
    ap.add_argument('--out', required=True, help='Output JSON path')
    args = ap.parse_args()

    preds = []
    for name in os.listdir(args.input):
        if name.lower().endswith(('.png','.jpg','.jpeg','.tif','.bmp')):
            path = os.path.join(args.input, name)
            if args.engine == 'pytesseract':
                res = ocr_pytesseract(path)
            else:
                res = ocr_easyocr(path)
            preds.append({'image': name, **res})

    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(preds, f, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    main()
