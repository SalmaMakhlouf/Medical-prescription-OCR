import argparse
import os
import cv2
import numpy as np
from PIL import Image

def deskew(image):
    # TODO: implement skew correction using cv2.getRotationMatrix2D or Hough lines
    return image

def binarize(image):
    # TODO: Otsu/adaptive threshold
    return cv2.threshold(image, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

def normalize(image):
    # TODO: intensity normalization if needed
    return image

def preprocess_path(in_path, out_dir):
    img = cv2.imread(in_path)
    if img is None:
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = normalize(gray)
    gray = deskew(gray)
    bw = binarize(gray)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, os.path.basename(in_path))
    cv2.imwrite(out_path, bw)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, help='Input folder with images')
    ap.add_argument('--out', required=True, help='Output folder for preprocessed images')
    args = ap.parse_args()
    for name in os.listdir(args.input):
        if name.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.bmp')):
            preprocess_path(os.path.join(args.input, name), args.out)

if __name__ == '__main__':
    main()
