import argparse, json

def precision_recall_f1(pred_items, gold_items):
    # TODO: implement entity-level PRF or simple exact-match on fields
    return {'precision': None, 'recall': None, 'f1': None}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pred', required=True)
    ap.add_argument('--gold', required=True)
    args = ap.parse_args()
    with open(args.pred, 'r', encoding='utf-8') as f:
        preds = json.load(f)
    with open(args.gold, 'r', encoding='utf-8') as f:
        gold = json.load(f)

    # TODO: align by filename and compute metrics
    metrics = precision_recall_f1(preds, gold.get('items', []))
    print(metrics)

if __name__ == '__main__':
    main()
